package com.example.prayerreminder.ui;

import android.app.Activity;
import android.os.Bundle;
import android.os.Vibrator;
import android.widget.TextView;

import com.example.prayerreminder.R;

public class AlarmScreenActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarm_screen);

        TextView alarmText = findViewById(R.id.alarmText);
        alarmText.setText("Prayer Time!\nTime to pray.");

        Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (v != null) {
            v.vibrate(1000);
        }
    }
}
