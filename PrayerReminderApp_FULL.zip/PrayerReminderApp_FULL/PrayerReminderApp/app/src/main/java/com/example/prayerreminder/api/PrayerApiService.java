// FILE: api/PrayerApiService.java
// ======================
package com.example.prayerreminder.api;

import com.example.prayerreminder.model.PrayerResponse;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface PrayerApiService {
    @GET("timings")
    Call<PrayerResponse> getPrayerTimes(
            @Query("latitude") double latitude,
            @Query("longitude") double longitude,
            @Query("method") int method
    );
}
