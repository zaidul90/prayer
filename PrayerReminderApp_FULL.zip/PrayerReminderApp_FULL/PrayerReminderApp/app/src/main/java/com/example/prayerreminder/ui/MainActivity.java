// FILE: ui/MainActivity.java
// ======================
package com.example.prayerreminder.ui;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.example.prayerreminder.R;
import com.example.prayerreminder.api.PrayerApiService;
import com.example.prayerreminder.api.RetrofitClient;
import com.example.prayerreminder.model.PrayerResponse;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private TextView prayerTimesText;
    private FusedLocationProviderClient fusedLocationClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prayerTimesText = findViewById(R.id.prayerTimesText);
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        } else {
            fetchLocationAndPrayerTimes();
        }
    }

    private void fetchLocationAndPrayerTimes() {
        fusedLocationClient.getLastLocation().addOnSuccessListener(this, location -> {
            if (location != null) {
                fetchPrayerTimes(location);
            }
        });
    }

    private void fetchPrayerTimes(Location location) {
        PrayerApiService service = RetrofitClient.getClient().create(PrayerApiService.class);
        Call<PrayerResponse> call = service.getPrayerTimes(location.getLatitude(), location.getLongitude(), 2);
        call.enqueue(new Callback<PrayerResponse>() {
            @Override
            public void onResponse(Call<PrayerResponse> call, Response<PrayerResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    StringBuilder sb = new StringBuilder();
                    for (String prayer : response.body().data.timings.keySet()) {
                        sb.append(prayer).append(" - ").append(response.body().data.timings.get(prayer)).append("\n");
                    }
                    prayerTimesText.setText(sb.toString());
                }
            }

            @Override
            public void onFailure(Call<PrayerResponse> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Failed to get prayer times", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == 1 && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            fetchLocationAndPrayerTimes();
        } else {
            Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show();
        }
    }
}
