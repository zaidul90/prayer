// FILE: model/PrayerResponse.java
// ======================
package com.example.prayerreminder.model;

import com.google.gson.annotations.SerializedName;
import java.util.Map;

public class PrayerResponse {
    @SerializedName("data")
    public Data data;

    public class Data {
        @SerializedName("timings")
        public Map<String, String> timings;
    }
}